"""
This module defines the App class used for creating a GUI application
for camera operations and image uploads.
"""
import threading
import tkinter as tk
from tkinter import filedialog
import random
import numpy as np
import cv2
import dlib
from PIL import Image, ImageTk
import os
from tkinter import messagebox
import ttkbootstrap as ttk
from ttkbootstrap.constants import *
from tensorflow.keras.models import load_model


class App:
    """
    A class used to represent the GUI application.

    ...

    Attributes
    ----------
    window : tk.Tk
        The main window of the application.
    cam_vid_capture : cv2.VideoCapture
        The video capturing object.
    canvas : tk.Canvas
        The canvas where video frames and images are displayed.
    btn_start_cam : tk.Button
        Button to start the camera feed.
    btn_upload_file : tk.Button
        Button to upload images.
    thread : threading.Thread
        The thread on which the video stream operates.
    canvas_width : int
        The width of the canvas.
    canvas_height : int
        The height of the canvas.
    imgtk : ImageTk.PhotoImage
        The image object compatible with Tkinter.

    Methods
    -------
    start_camera():
        Starts the camera feed.
    video_stream():
        Retrieves video frames and displays them on the canvas.
    upload_file():
        Opens a dialog to upload files.
    display_image(path):
        Displays an image on the canvas.
    on_closing():
        Releases video capture and closes the window.
    """

    def __init__(self, window, window_title, dnn_model_path, cnn_model_path, model_path):
        """
        Initialize the AgeRecognitionApp class.

        Args:
            window (tkinter.Tk): The main window of the application.
            window_title (str): The title of the window.
            dnn_model_path (str): The file path of the DNN model for face detection.
            cnn_model_path (str): The file path of the CNN model for face detection.
        """
        self.window = window
        self.window.title(window_title)
        self.age_model = load_model(model_path)

        # Set the grid layout for the window
        for row_index in range(10):
            window.rowconfigure(row_index, weight=1)
        window.columnconfigure(0, weight=1)

        # Canvas for video frames and images
        self.canvas = tk.Canvas(window)
        self.canvas.grid(row=0, column=0, rowspan=5, sticky="nsew")

        # Dropdown menu for face detection choice
        self.optmenu_options = [
            'dlib cnn face recognition', 'opencv dnn face recognition']
        self.optmenu_variable = tk.StringVar()
        self.optmenu_variable.set(self.optmenu_options[0])
        self.optmenu_face_det_choice = tk.OptionMenu(
            window, self.optmenu_variable, *self.optmenu_options, command=self.optmenu_change_of_choice)
        self.optmenu_face_det_choice.grid(
            row=5, column=0, sticky="ew", padx=10, pady=10)

        # Progress bar
        self.progress_bar = ttk.Progressbar(
            window, orient="horizontal", bootstyle="success-striped", length=300, mode="determinate")
        self.progress_bar.grid(row=6, column=0, sticky="ew", padx=10, pady=10)

        # Buttons
        self.btn_start_cam = ttk.Button(
            window, text="Start Camera", command=self.start_camera)  # bootstyle="primary-outline-link",
        self.btn_start_cam.grid(row=7, column=0, sticky="ew", padx=10, pady=10)

        self.btn_upload_file = ttk.Button(
            window, text="Upload File", command=self.upload_file)
        self.btn_upload_file.grid(
            row=8, column=0, sticky="ew", padx=10, pady=10)

        self.btn_upload_video = ttk.Button(
            window, text="Upload Video", command=self.upload_video)
        self.btn_upload_video.grid(
            row=9, column=0, sticky="ew", padx=10, pady=10)

        self.btn_select_directory = ttk.Button(
            window, text="Select Directory", command=self.process_directory)
        self.btn_select_directory.grid(
            row=10, column=0, sticky="ew", padx=10, pady=10)

        self.btn_clear_canvas = ttk.Button(
            window, text="Clear Canvas", bootstyle="danger-outline", command=self.clear_canvas)
        self.btn_clear_canvas.grid(
            row=11, column=0, sticky="ew", padx=10, pady=10)

        self.btn_save = ttk.Button(
            window, text="Save Current", bootstyle="success-outline", command=self.save_current)
        self.btn_save.grid(row=12, column=0, sticky="ew", padx=10, pady=10)

        self.window.protocol("WM_DELETE_WINDOW", self.on_closing)

        self.dnn_is_used = False
        self.cnn_is_used = True
        try:
            self.dnn_face_detector = cv2.dnn.readNetFromCaffe(*dnn_model_path)
        except Exception as e:
            print(f"Error loading DNN model: {e}")
            exit(1)

        try:
            self.cnn_face_detector = dlib.cnn_face_detection_model_v1(
                cnn_model_path)
        except Exception as e:
            print(f"Error loading CNN model: {e}")
            exit(1)
        self.dnn_face_detector = cv2.dnn.readNetFromCaffe('deploy.prototxt.txt',
                                                          'res10_300x300_ssd_iter_140000.caffemodel')
        self.cnn_face_detector = dlib.cnn_face_detection_model_v1(
            'mmod_human_face_detector.dat')

        self.cam_vid_capture = None
        self.canvas_width = None
        self.canvas_height = None
        self.thread = None
        self.imgtk = None

    def update_canvas_size(self):
        """Update the canvas dimensions.

        This method updates the dimensions of the canvas based on its current content.
        It calls the `update()` method of the canvas to ensure that all pending events are processed.
        Then, it retrieves the width and height of the canvas using the `winfo_width()` and `winfo_height()` methods.

        """
        self.canvas.update()
        self.canvas_width = self.canvas.winfo_width()
        self.canvas_height = self.canvas.winfo_height()

    def optmenu_change_of_choice(self, selected):
        """
        Change the choice of detection mode based on the selected option.

        Args:
            selected (str): The selected detection mode option.

        Returns:
            None
        """
        detection_modes = {
            'dlib cnn face recognition': {'cnn': True, 'dnn': False},
            'opencv dnn face recognition': {'cnn': False, 'dnn': True}
        }

        if selected in detection_modes:
            self.cnn_is_used = detection_modes[selected]['cnn']
            self.dnn_is_used = detection_modes[selected]['dnn']
        else:
            print(f"Warning: Unrecognized selection '{selected}'")

    def start_camera(self):
        """Starts the camera feed."""
        try:
            if self.cam_vid_capture is not None:
                self.cam_vid_capture.release()
            self.cam_vid_capture = cv2.VideoCapture(0)
            if not self.cam_vid_capture.isOpened():
                raise ValueError("Could not open video device")
            self.video_stream(cam_cap=True)
        except Exception as e:
            print(f"Error starting camera: {e}")

    def upload_file(self):
        """
        Opens a dialog to upload an image file, applies face detection, 
        and displays the processed image. The method handles errors in image reading 
        and provides feedback in case of failure.
        """
        filepath = filedialog.askopenfilename(
            title="Open Image File", filetypes=[("Image files", "*.png *.jpg *.jpeg")]
        )
        if filepath:
            try:
                pil_image = Image.open(filepath)
                cv2image = np.array(pil_image)
                # Convert RGB to BGR for OpenCV
                cv2image = cv2image[:, :, ::-1].copy()

                if self.cnn_is_used:
                    cv2image = self.cnn_face_detection(cv2image)
                elif self.dnn_is_used:
                    cv2image = self.dnn_face_detection(cv2image)

                cv2image = cv2.cvtColor(cv2image, cv2.COLOR_BGR2RGB)
                img = Image.fromarray(cv2image)
                self.display_image(img)
            except Exception as e:
                print(f"Error in reading or processing image: {e}")
        else:
            print("No file selected.")

    def upload_video(self):
        """
        Uploads a video file and starts the video stream.

        Returns:
            None
        """
        allowed_file_types = [("Video files", "*.mp4 *.avi *.mov")]

        filepath = filedialog.askopenfilename(
            title="Open Video File", filetypes=allowed_file_types)
        if filepath:
            try:
                if self.cam_vid_capture is not None:
                    self.cam_vid_capture.release()

                self.cam_vid_capture = cv2.VideoCapture(filepath)
                if not self.cam_vid_capture.isOpened():
                    raise ValueError("Could not open video file")

                self.video_stream()
            except Exception as e:
                print(f"Error uploading video: {e}")
                if self.cam_vid_capture is not None:
                    self.cam_vid_capture.release()

    def clear_canvas(self):
        """
        Clears the canvas by releasing the video capture, updating the canvas size,
        and deleting all items on the canvas.

        Args:
            None

        Returns:
            None
        """
        if self.cam_vid_capture is not None:
            self.cam_vid_capture.release()
        self.update_canvas_size()
        if self.canvas is not None:
            self.canvas.delete('all')
        else:
            print("Canvas does not exist.")

    def video_stream(self, cam_cap=False):
        """Retrieves video frames and updates the canvas.

        Args:
            cam_cap (bool, optional): Flag indicating whether to flip the video frames horizontally. 
                                     Defaults to False.

        Returns:
            None
        """
        self.is_current_video = True
        while True:
            ret, frame = self.cam_vid_capture.read()
            if not ret:
                break
            if cam_cap:
                frame = cv2.flip(frame, 1)

            if self.cnn_is_used:
                frame = self.cnn_face_detection(frame)
            elif self.dnn_is_used:
                frame = self.dnn_face_detection(frame)

            if frame is None:
                continue

            frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            img = Image.fromarray(frame)
            self.display_image(img)

    def display_image(self, img):
        """
        Displays the selected image file on the canvas.

        Parameters:
        img (PIL.Image.Image): The image to be displayed on the canvas.
        """
        self.update_canvas_size()

        self.current_display = img.copy()  # Store the current image
        self.is_current_video = False

        img_width, img_height = img.size

        scale = min(self.canvas_width / img_width,
                    self.canvas_height / img_height)
        new_width = int(img_width * scale)
        new_height = int(img_height * scale)

        resized_img = img.resize((new_width, new_height), Image.LANCZOS)
        self.imgtk = ImageTk.PhotoImage(image=resized_img)

        self.canvas.create_image((self.canvas_width - new_width) // 2, (self.canvas_height - new_height) // 2,
                                 anchor=tk.NW, image=self.imgtk)
        img.close()

        self.window.update()

    def on_closing(self):
        """Releases the video capture and destroys the application window.

        This method is called when the application window is being closed. It releases the video capture
        if it is not None and destroys the application window.
        """
        if self.cam_vid_capture is not None:
            self.cam_vid_capture.release()
        self.window.destroy()

    def dnn_face_detection(self, img):
        """
        Detects faces using DNN model and draws bounding boxes with a random number as age.
        """
        # Get the dimensions of the frame
        (h, w) = img.shape[:2]

        # Create a blob from the frame to pass to the deep learning network
        blob = cv2.dnn.blobFromImage(cv2.resize(img, (300, 300)), 1.0,
                                     (300, 300), (104.0, 177.0, 123.0))

        # Pass the blob through the network and obtain the detections and predictions
        self.dnn_face_detector.setInput(blob)
        detections = self.dnn_face_detector.forward()

        # Loop over the detections
        for i in range(0, detections.shape[2]):
            # Extract the confidence (i.e., probability) associated with the prediction
            confidence = detections[0, 0, i, 2]

            # Filter out weak detections by ensuring the confidence is greater than a minimum threshold
            if confidence > 0.5:
                # Compute the (x, y)-coordinates of the bounding box for the object
                box = detections[0, 0, i, 3:7] * np.array([w, h, w, h])
                (startX, startY, endX, endY) = box.astype("int")

                # Draw the bounding box of the face along with the associated probability
                cv2.rectangle(img, (startX, startY),
                              (endX, endY), (0, 255, 0), 2)

                face_img = img[startY:endY, startX:endX]
                if face_img is None or face_img.size == 0:
                    continue

                processed_face = self.preprocess_face(face_img)
                age_prediction = self.age_model.predict(processed_face, verbose=0)
                predicted_age = round(age_prediction[0][0])
                cv2.putText(img, f'Age: {predicted_age}', (startX, startY - 10),
                            cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)

        return img

    def cnn_face_detection(self, img):
        """
        Performs face detection using a CNN model and predicts the age of each detected face.

        Args:
            img (numpy.ndarray): The input image.

        Returns:
            numpy.ndarray: The image with rectangles drawn around the detected faces and predicted ages displayed.
        """
        rgb_img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        faces = self.cnn_face_detector(rgb_img)

        for face in faces:
            # Extracting the coordinates of the detected face
            startX = face.rect.left()
            startY = face.rect.top()
            endX = face.rect.right()
            endY = face.rect.bottom()

            # Drawing the rectangle around the face
            cv2.rectangle(img, (startX, startY), (endX, endY), (0, 255, 0), 2)

            # Cropping the face for age prediction
            face_img = rgb_img[startY:endY, startX:endX]
            if face_img is None or face_img.size == 0:
                continue

            processed_face = self.preprocess_face(face_img)
            # Predicting the age
            age_prediction = self.age_model.predict(processed_face, verbose=0)
            predicted_age = round(age_prediction[0][0])

            # Displaying the predicted age
            cv2.putText(img, f'Age: {predicted_age}', (startX, startY - 10),
                        cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)

        return img

    def process_directory(self):
        """
        Process all files in a selected directory.

        This method prompts the user to select a directory and then processes all the files
        in that directory. It supports image files with extensions '.png', '.jpg', '.jpeg',
        and video files with extensions '.mp4', '.avi', '.mov'. The method updates a progress
        bar to indicate the progress of the processing.

        Returns:
            None
        """
        directory_path = filedialog.askdirectory()
        if directory_path:
            files = [f for f in os.listdir(directory_path) if f.lower().endswith(
                ('.png', '.jpg', '.jpeg', '.mp4', '.avi', '.mov'))]
            total_files = len(files)

            self.progress_bar["maximum"] = total_files
            self.progress_bar["value"] = 0

            for idx, filename in enumerate(files, start=1):
                file_path = os.path.join(directory_path, filename)
                if filename.lower().endswith(('.png', '.jpg', '.jpeg')):
                    self.process_image(file_path, directory_path)
                elif filename.lower().endswith(('.mp4', '.avi', '.mov')):
                    self.process_video(file_path, directory_path)

                self.progress_bar["value"] = idx
                self.window.update_idletasks()  # Update the progress bar

            messagebox.showinfo("Processing Complete",
                                f"Processed {total_files} files.")

    def process_image(self, image_path, directory_path):
        """
        Process the given image by performing face detection using either CNN or DNN,
        and save the processed image to the specified directory.

        Args:
            image_path (str): The path to the input image file.
            directory_path (str): The path to the directory where the processed image will be saved.

        Returns:
            None
        """
        try:
            pil_image = Image.open(image_path)
            cv2image = np.array(pil_image)
            cv2image = cv2image[:, :, ::-1].copy()  # Convert RGB to BGR

            if self.cnn_is_used:
                cv2image = self.cnn_face_detection(cv2image)
            elif self.dnn_is_used:
                cv2image = self.dnn_face_detection(cv2image)

            # Convert back to PIL image and save
            processed_image = Image.fromarray(
                cv2.cvtColor(cv2image, cv2.COLOR_BGR2RGB))
            save_path = os.path.join(directory_path, "processed")
            if not os.path.exists(save_path):
                os.makedirs(save_path)
            processed_image.save(os.path.join(
                save_path, os.path.basename(image_path)))
        except Exception as e:
            print(f"Error processing {os.path.basename(image_path)}: {e}")

    def process_video(self, video_path, directory_path):
        """
        Process a video by performing face detection on each frame and saving the processed video.

        Args:
            video_path (str): The path to the input video file.
            directory_path (str): The path to the directory where the processed video will be saved.

        Raises:
            Exception: If there is an error processing the video.

        Returns:
            None
        """
        try:
            cap = cv2.VideoCapture(video_path)
            frame_width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
            frame_height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
            fps = cap.get(cv2.CAP_PROP_FPS)

            save_path = os.path.join(directory_path, "processed")
            if not os.path.exists(save_path):
                os.makedirs(save_path)
            output_path = os.path.join(save_path, os.path.basename(video_path))

            # Change codec to 'mp4v' for MP4 files
            out = cv2.VideoWriter(output_path, cv2.VideoWriter_fourcc(
                *'mp4v'), fps, (frame_width, frame_height))

            while True:
                ret, frame = cap.read()
                if not ret:
                    break

                if self.cnn_is_used:
                    frame = self.cnn_face_detection(frame)
                elif self.dnn_is_used:
                    frame = self.dnn_face_detection(frame)

                out.write(frame)

            cap.release()
            out.release()
        except Exception as e:
            print(
                f"Error processing video {os.path.basename(video_path)}: {e}")

    def save_current(self):
        """
        Saves the current image or video frame.

        If the current item is a video, an error message is displayed as saving video frames is not supported.
        If the current item is an image, a file dialog is opened to select the save location and format.
        The image is then saved to the selected file path and a success message is displayed.
        If there is no current image, an error message is displayed.
        """
        if self.is_current_video:
            messagebox.showerror(
                "Save Error", "Saving video frames is not supported.")
            return

        if self.current_display is not None:
            file_path = filedialog.asksaveasfilename(defaultextension=".jpg",
                                                     filetypes=[("JPEG files", "*.jpg"), ("PNG files", "*.png"), ("All files", "*.*")])
            if file_path:
                self.current_display.save(file_path)
                messagebox.showinfo("Save Successful",
                                    f"Image saved to {file_path}")
        else:
            messagebox.showerror("Save Error", "No image to save.")

    def preprocess_face(self, img):
        """
        Preprocesses a face image by resizing it to 128x128, converting it to grayscale,
        normalizing pixel values, and adding channel and batch dimensions.

        Args:
            img (numpy.ndarray): The input face image.

        Returns:
            numpy.ndarray: The preprocessed face image.
        """

        processed_img = cv2.resize(img, (128, 128))  # Resize to 128x128

        if self.cnn_is_used:
            processed_img = cv2.cvtColor(
                processed_img, cv2.COLOR_RGB2GRAY)  # Convert to grayscale
        if self.dnn_is_used:
            processed_img = cv2.cvtColor(
                processed_img, cv2.COLOR_BGR2GRAY)  # Convert to grayscale

        processed_img = np.expand_dims(
            processed_img, axis=-1)  # Add channel dimension
        processed_img = np.expand_dims(
            processed_img, axis=0)  # Add batch dimension
        return processed_img


if __name__ == "__main__":
    print('CUDA support for dlib:', dlib.DLIB_USE_CUDA)
    root = ttk.Window(themename="darkly")
    app = App(root, "ML Project App", ('deploy.prototxt.txt',
              'res10_300x300_ssd_iter_140000.caffemodel'), 'mmod_human_face_detector.dat',
              'model_v5.h5')
    root.mainloop()
